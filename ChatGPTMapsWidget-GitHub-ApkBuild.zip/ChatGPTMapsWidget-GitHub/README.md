# ChatGPT Maps Widget – Android

Három próba egy projektben:
1. ChatGPT Maps: ChatGPT megnyitása.
2. Google Maps: Android térképes alkalmazás megnyitása.
3. Saját térkép: hely a későbbi saját Google Maps + AI integrációhoz.

## Telepítés
- Nyisd meg ezt a mappát Android Studióban.
- Gradle sync.
- Futtasd telefonon/emulátoron.
- A kezdőképernyőn: Widgetek -> ChatGPT Maps Widget.

## Fontos
A „ChatGPT Maps” nem egy külön, dokumentált Android Intentként megnyitható rendszerfunkció, ezért az első gomb jelenleg a ChatGPT webes felületét nyitja meg.
A saját AI-térképes változathoz érdemes az OpenAI API-hívást szerveroldalra tenni, nem közvetlenül az APK-ba égetett API-kulccsal.
Az OpenAI jelenleg a Responses API-t használja az új modellekhez.
