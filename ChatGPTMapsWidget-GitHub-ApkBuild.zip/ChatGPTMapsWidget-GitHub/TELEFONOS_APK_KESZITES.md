# APK készítése Android Studio nélkül

## Telefonról

1. Nyiss meg egy GitHub-fiókot, ha még nincs.
2. Hozz létre egy új, üres repositoryt.
3. A projekt összes fájlját töltsd fel a repositoryba.
4. Nyisd meg: **Actions**.
5. Válaszd a **Build APK** workflow-t.
6. Nyomd meg: **Run workflow**.
7. A futás végén nyisd meg a sikeres futást.
8. Az **Artifacts** résznél töltsd le a `ChatGPTMapsWidget-debug` csomagot.
9. A ZIP-ben találod az `app-debug.apk` fájlt.
10. Telepítsd az APK-t Androidon. Ha a rendszer kéri, engedélyezd a böngésző/fájlkezelő számára az ismeretlen alkalmazások telepítését.

## Mit tartalmaz?
- ChatGPT gomb
- Google Maps gomb
- Saját térkép / AI gomb
- Android kezdőképernyős widget

## Fontos
Ez debug APK. Saját használatra teszteléshez megfelelő. Nyilvános terjesztéshez érdemes aláírt release APK-t készíteni.
