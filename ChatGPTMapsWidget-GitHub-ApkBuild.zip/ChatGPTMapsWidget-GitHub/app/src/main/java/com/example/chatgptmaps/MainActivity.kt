package com.example.chatgptmaps

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.widget.LinearLayout

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        root.addView(TextView(this).apply {
            text = "ChatGPT Maps – 3 próba"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "1. ChatGPT: megnyitja a ChatGPT-t.\n2. Google Maps: megnyitja a Google Maps-t.\n3. Saját térkép: itt indítható később API-s térképes/AI funkció."
            textSize = 16f
            setPadding(0,24,0,24)
        })
        root.addView(Button(this).apply {
            text = "1 – ChatGPT Maps"
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/"))) }
        })
        root.addView(Button(this).apply {
            text = "2 – Google Maps"
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))) }
        })
        root.addView(Button(this).apply {
            text = "3 – Saját térkép / AI"
            setOnClickListener { 
                android.widget.Toast.makeText(this@MainActivity,
                    "A saját térképes részhez Google Maps API-kulcs és opcionálisan OpenAI API-kulcs adható hozzá.",
                    android.widget.Toast.LENGTH_LONG).show()
            }
        })
        setContentView(root)
    }
}
