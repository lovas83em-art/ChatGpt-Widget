package com.example.chatgptmaps

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

class MapsWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_maps)
            views.setOnClickPendingIntent(R.id.chatgpt, pending(context, "https://chatgpt.com/"))
            views.setOnClickPendingIntent(R.id.google, pending(context, "geo:0,0?q="))
            views.setOnClickPendingIntent(R.id.custom, pending(context, null))
            manager.updateAppWidget(id, views)
        }
    }
    private fun pending(context: Context, url: String?): android.app.PendingIntent {
        val intent = if (url == null) Intent(context, MainActivity::class.java)
        else Intent(Intent.ACTION_VIEW, Uri.parse(url))
        return android.app.PendingIntent.getActivity(
            context, url?.hashCode() ?: 99, intent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
    }
}
